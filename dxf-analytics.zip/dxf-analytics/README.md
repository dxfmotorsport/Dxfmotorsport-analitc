# DXF Analytics — Panel de Análisis IA para Shopify

Panel de análisis automático que conecta tu tienda Shopify con Claude (IA de Anthropic) para detectar mejoras de captación y conversión.

---

## Despliegue en Vercel (5 minutos)

### 1. Sube este proyecto a GitHub

1. Ve a github.com → New repository
2. Nombre: `dxf-analytics`
3. Sube todos los archivos de esta carpeta

### 2. Despliega en Vercel

1. Ve a vercel.com → Add New Project
2. Importa el repositorio `dxf-analytics` desde GitHub
3. Deja toda la configuración por defecto
4. Pulsa **Deploy**

### 3. Añade las variables de entorno en Vercel

En tu proyecto de Vercel → Settings → Environment Variables, añade estas tres:

| Variable | Valor |
|----------|-------|
| `SHOPIFY_STORE` | `dxfmotorsport.myshopify.com` |
| `SHOPIFY_TOKEN` | El token que generaste en Shopify |
| `ANTHROPIC_API_KEY` | La clave de API de Anthropic |

Después de añadirlas, ve a **Deployments → Redeploy** para que se apliquen.

### 4. Usa el panel

La URL del panel será algo como:
```
https://dxf-analytics.vercel.app
```

Abre esa URL, introduce tu configuración y pulsa "Analizar tienda".

---

## Estructura del proyecto

```
dxf-analytics/
├── api/
│   └── analyze.js      ← Backend: recoge datos de Shopify y llama a Claude
├── public/
│   └── index.html      ← Panel de análisis (frontend)
├── package.json
├── vercel.json
└── README.md
```

---

## Seguridad

- Las API keys nunca se exponen en el frontend
- Todo pasa por el backend en Vercel
- El token de Shopify tiene permisos de solo lectura
